% Paper Reference
% B. Parker, "Modelling and Optimisation of Lattice Structures [UGthesis],"
% University of New South Wales Canberra, Tech. Rep., 2020.

% Appendix H, Example 1

function [f,g] = Example10_2(x)
if nargin == 0
    prob.name='Concept 2';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx = 3;
    prob.f1='f1';
    prob.f2='f2';
    
    % Define the variable bounds of the concepts here
    for i = 1:prob.nx
        prob.range(i,:) = [0,2*pi];
    end
    f = prob;
    g = [];
else
    [f,g] = Example10_2_true(x);
end
return

function [f,g] = Example10_2_true(x)
    f(:,1)=x(:,3)+x(:,2)+0.5+cos(x(:,1));
    f(:,2)=x(:,3)+x(:,2)+2+sin(x(:,1));
    g = [];
return