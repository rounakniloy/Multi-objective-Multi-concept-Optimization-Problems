% Paper Reference
% B. Parker, "Modelling and Optimisation of Lattice Structures [UGthesis],"
% University of New South Wales Canberra, Tech. Rep., 2020.

% Appendix H, Example 1

function [f,g] = Example10_3(x)
if nargin == 0
    prob.name='Concept 3';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx = 4;
    prob.f1='f1';
    prob.f2='f2';
    
    % Define the variable bounds of the concepts here
    for i = 1:prob.nx
        prob.range(i,:) = [0,2*pi];
    end
    f = prob;
    g = [];
else
    [f,g] = Example10_3_true(x);
end
return

function [f,g] = Example10_3_true(x)
    f(:,1)=x(:,4)+x(:,3)+x(:,2)+2+cos(x(:,1));
    f(:,2)=x(:,4)+x(:,3)+x(:,2)+1+sin(x(:,1));
    g = [];
return