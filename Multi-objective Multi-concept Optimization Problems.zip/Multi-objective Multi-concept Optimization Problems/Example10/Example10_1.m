% Paper Reference
% B. Parker, "Modelling and Optimisation of Lattice Structures [UGthesis],"
% University of New South Wales Canberra, Tech. Rep., 2020.

% Appendix H, Example 1

function [f,g] = Example10_1(x)
if nargin == 0
    prob.name='Concept 1';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx=2;
    prob.f1='f1';
    prob.f2='f2';
    
    % Define the variable bounds of the concepts here
    for i = 1:prob.nx
        prob.range(i,:) = [0,2*pi];
    end
    f = prob;
    g = [];
else
    [f,g] = Example10_1_true(x);
end
return

function [f,g] = Example10_1_true(x)
    % Create geometry with this x(:,1) and x(:,2)
    f(:,1)=1+x(:,2)+cos(x(:,1));
    f(:,2)=1.5+x(:,2)+sin(x(:,1));
    g = [];
return