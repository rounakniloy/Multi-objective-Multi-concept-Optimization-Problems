% Paper Reference
% G. Avigad and A. Moshaiov, "Interactive evolutionary multiobjective search and optimization
% of set-based concepts," IEEE Trans. Syst., Man, Cybern. B, Cybern,
% vol. 39, no. 4, pp. 1013–1027, 2009
% Example C

function [f,g] = Example6_4(x)
if nargin == 0
    prob.name='Concept 4';
    prob.nf = 2;
    prob.ng = 4;
    prob.nx = 2;
    prob.f1='f1';
    prob.f2='f2';

    % Define the variable bounds of the concepts here
    prob.range(1,:) = [-2 2]; 
    prob.range(2,:) = [-2 2];  
    
    f = prob;
    g = [];
else
    [f,g] = Example6_4_true(x);
end
return

function [f,g] = Example6_4_true(x)
g = [];

a=0.8;
b=1;

f(:,1)=x(:,1);
f(:,2)=a+(x(:,2)).^2-x(:,1)-0.1*cos(b*pi*x(:,1));

g(:,1)=f(:,1)-0.8;
g(:,2)=f(:,2)-0.7;
g(:,3)=-f(:,1);
g(:,4)=-f(:,2);

return