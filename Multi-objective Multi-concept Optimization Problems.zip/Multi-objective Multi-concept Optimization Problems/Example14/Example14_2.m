% Paper Reference
% G. Avigad, "Search and selection of concepts in multi-objective engineering 
% problems using evolutionary algorithms," Ph.D. dissertation, 
% Tel Aviv University, 2007.

% Ch. 4, Ex. 4.1.2-A

function [f,g] = Example14_2(x)
if nargin == 0
    prob.name='Concept 2';
    prob.nf = 2;
    prob.ng = 4;
    prob.nx = 2;
    prob.f1='f1';
    prob.f2='f2';

    % Define the variable bounds of the concepts here
    prob.range(1,:) = [-2 2];   
    prob.range(2,:) = [-2 2];

    f = prob;
    g = [];
else
    [f,g] = Example14_2_true(x);
end
return

function [f,g] = Example14_2_true(x)
g = [];

f=zeros(size(x,1),2);
g=zeros(size(x,1),4);


f(:,1)=x(:,1);
f(:,2)=0.87+x(:,2).^2-x(:,1)-0.1*sin(3*pi*x(:,1));

g(:,1)=f(:,1)-0.9;
g(:,2)=f(:,2)-0.9;
g(:,3)=-f(:,1);
g(:,4)=-f(:,2);

return