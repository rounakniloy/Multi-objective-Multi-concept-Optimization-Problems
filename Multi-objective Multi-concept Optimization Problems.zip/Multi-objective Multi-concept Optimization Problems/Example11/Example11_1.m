% Paper Reference
% G. Avigad, "Search and selection of concepts in multi-objective engineering 
% problems using evolutionary algorithms," Ph.D. dissertation, 
% Tel Aviv University, 2007.

% Ch. 4, Ex. 4.1.1-B

function [f,g] = Example11_1(x)
if nargin == 0
    prob.name='Concept 1';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx=1;
    prob.f1='f1';
    prob.f2='f2';
    
    % Define the variable bounds of the concepts here
    for i = 1:prob.nx
        prob.range(i,:) = [0,5];
    end
    f = prob;
    g = [];
else
    [f,g] = Example11_1_true(x);
end
return

function [f,g] = Example11_1_true(x)
    f(:,1)=x(:,1);
    f(:,2)=(x(:,1)-1).^2;
    g = [];
return