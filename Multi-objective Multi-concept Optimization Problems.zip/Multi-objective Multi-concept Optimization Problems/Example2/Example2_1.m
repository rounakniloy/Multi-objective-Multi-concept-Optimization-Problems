% Paper Reference
% G. Avigad and A. Moshaiov, "Simultaneous concept-based evolutionary
% multi-objective optimization," Appl. Soft Comput., vol. 11, no. 1, pp.
% 193–207, 2011.
% Example 1


function [f,g] = Example2_1(x)
if nargin == 0
    prob.name='Concept 1';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx = 1;
    prob.f1='f1';
    prob.f2='f2';


    % Define the variable bounds of the concepts here
    prob.range(1,:) = [0 5];   
    
    f = prob;
    g = [];
else
    [f,g] = Example2_1_true(x);
end
return

function [f,g] = Example2_1_true(x)
g = [];

f=zeros(size(x,1),2);
for i=1:size(x,1)
    f(i,1)=x(i,1);
    f(i,2)=(x(i,1)-1)^2;
end

return