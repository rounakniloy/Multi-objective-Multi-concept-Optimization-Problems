%% WRONG PROBLEM FORMULATION

% Paper Reference
% G. Avigad and A. Moshaiov, "Simultaneous concept-based evolutionary
% multi-objective optimization," Appl. Soft Comput., vol. 11, no. 1, pp.
% 193–207, 2011.
% Example 1


function [f,g] = Example2_2(x)
if nargin == 0
    prob.name='Concept 2';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx = 2;
    prob.f1='f1';
    prob.f2='f2';

    % Define the variable bounds of the concepts here
    prob.range(1,:) = [0.01 0.08];   
    prob.range(2,:) = [-2 5];

    f = prob;
    g = [];
else
    [f,g] = Example2_2_true(x);
end
return

function [f,g] = Example2_2_true(x)
g = [];

f=zeros(size(x,1),2);
for i=1:size(x,1)
    f(i,1)=0.4+x(i,1);
    f(i,2)=0.1+(x(i,2)/x(i,1));
end

return