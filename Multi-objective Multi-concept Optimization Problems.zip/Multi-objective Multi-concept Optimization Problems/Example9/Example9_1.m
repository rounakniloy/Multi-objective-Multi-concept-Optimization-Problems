% Paper Reference
% G. Avigad, A. Moshaiov, and N. Brauner, "Pareto-directed interactive 
% concept-based evolution," Online tech report, 2004, Accessed: (21/09/2023). 
% [Online]. Available: https://www.researchgate.net/publication/228995043_Pareto-directed_Interactive_Concept-based_Evolution
% Example 5

function [f,g] = Example9_1(x)
if nargin == 0
    prob.name='Concept 1';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx = 1;
    prob.f1='f1';
    prob.f2='f2';

    % Define the variable bounds of the concepts here
    prob.range(1,:) = [-10 10];  
    
    f = prob;
    g = [];
else
    [f,g] = Example9_1_true(x);
end
return

function [f,g] = Example9_1_true(x)
g = [];
b=1;
c=2;
d=1;

f(:,1)=x(:,1).^2+b*c;
f(:,2)=(x(:,1)-2).^2+b*d;
return