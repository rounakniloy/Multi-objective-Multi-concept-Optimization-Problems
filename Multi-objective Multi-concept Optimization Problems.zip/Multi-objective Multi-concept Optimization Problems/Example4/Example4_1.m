% Paper Reference
% C. A. Mattson, "A new paradigm for concept selection in engineering
% design using multiobjective optimization," Ph.D. dissertation, Rensselaer
% Polytechnic Institute, 2003.

% Ch.7, Ex. 7.3

function [f,g] = Example4_1(x)
if nargin == 0
    prob.name='Concept 1';
    prob.nf = 3;
    prob.ng = 1;
    prob.nx = 3;
    prob.f1='f1';
    prob.f2='f2';
    prob.f3='f3';

    % Define the variable bounds of the concepts here
    prob.range(1,:) = [0 2];  
    prob.range(2,:) = [0 2];  
    prob.range(3,:) = [0 2];   
    
    f = prob;
    g = [];
else
    [f,g] = Example4_1_true(x);
end
return

function [f,g] = Example4_1_true(x)
g = [];

% f=zeros(size(x,1),3);
% for i=1:size(x,1)
%     f(i,1)=x(i,1);
%     f(i,2)=x(i,2);
%     f(i,3)=x(i,3);
% 
%     g(i,1)=((f(i,1)-1.5)^2+(f(i,2)-1.5)^2+(f(i,3)-1.5)^2-0.95);
% end

    f(:,1)=x(:,1);
    f(:,2)=x(:,2);
    f(:,3)=x(:,3);

    g(:,1)=((f(:,1)-1.5).^2+(f(:,2)-1.5).^2+(f(:,3)-1.5).^2-0.95);

return