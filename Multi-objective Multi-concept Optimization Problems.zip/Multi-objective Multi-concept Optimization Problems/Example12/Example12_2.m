% Paper Reference
% G. Avigad, "Search and selection of concepts in multi-objective engineering 
% problems using evolutionary algorithms," Ph.D. dissertation, 
% Tel Aviv University, 2007.

% Ch. 4, Ex. 4.1.2-E

function [f,g] = Example12_2(x)
if nargin == 0
    prob.name='Concept 1';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx=1;
    prob.f1='f1';
    prob.f2='f2';
    
    % Define the variable bounds of the concepts here
    for i = 1:prob.nx
        prob.range(i,:) = [0,5];
    end
    f = prob;
    g = [];
else
    [f,g] = Example12_2_true(x);
end
return

function [f,g] = Example12_2_true(x)
    f(:,1)=3+x(:,1);
    f(:,2)=30+(x(:,1)-3.5).^2;
    g = [];
return