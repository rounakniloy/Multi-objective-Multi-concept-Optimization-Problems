% Paper Reference
% C. A. Mattson and A. Messac, “A Non-Deterministic Approach to Concept 
% Selection Using sPareto Frontiers,” in International Design Engineering 
% Technical Conferences and Computers and Information in Engineering Conference,
% vol. 2, 09 2002, pp. 859–870.

% Example 1

function [f,g] = Example7_1(x)
if nargin == 0
    prob.name='Concept 1';
    prob.nf = 2;
    prob.ng = 4;
    prob.nx = 1;
    prob.f1='f1';
    prob.f2='f2';

    % Define the variable bounds of the concepts here
    prob.range(1,:) = [0 pi/2];   

    f = prob;
    g = [];
else
    [f,g] = Example7_1_true(x);
end
return

function [f,g] = Example7_1_true(x)
g = [];

f(:,1)=sin(x(:,1));
f(:,2)=1-(sin(x(:,1))).^7;

g(:,1)=f(:,1)-1;
g(:,2)=f(:,2)-1;
g(:,3)=0.5-f(:,1);
g(:,4)=0.4-f(:,2);
return