% Paper Reference
% G. Avigad and A. Moshaiov, "Interactive evolutionary multiobjective search and optimization
% of set-based concepts," IEEE Trans. Syst., Man, Cybern. B, Cybern,
% vol. 39, no. 4, pp. 1013–1027, 2009
% Example A

function [f,g] = Example5_1(x)
if nargin == 0
    prob.name='Concept 1';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx = 1;
    prob.f1='f1';
    prob.f2='f2';

    % Define the variable bounds of the concepts here
    prob.range(1,:) = [-5 5];  
    
    f = prob;
    g = [];
else
    [f,g] = Example5_1_true(x);
end
return

function [f,g] = Example5_1_true(x)
g = [];
b=0;

f(:,1)=x(:,1).^2+b;
f(:,2)=(x(:,1)-2).^2+b;
return