% Paper Reference
% G. Avigad and A. Moshaiov, "Interactive evolutionary multiobjective search and optimization
% of set-based concepts," IEEE Trans. Syst., Man, Cybern. B, Cybern,
% vol. 39, no. 4, pp. 1013–1027, 2009
% Example A

function [f,g] = Example5_2(x)
if nargin == 0
    prob.name='Concept 2';
    prob.nf = 2;
    prob.ng = 0;
    prob.nx = 1;
    prob.f1='f1';
    prob.f2='f2';

    % Define the variable bounds of the concepts here
    prob.range(1,:) = [-5 5];  
    
    f = prob;
    g = [];
else
    [f,g] = Example5_2_true(x);
end
return

function [f,g] = Example5_2_true(x)
g = [];
b=5;
% f=zeros(size(x,1),2);
% for i=1:size(x,1)
%     f(i,1)=x(i,1)^2+b;
%     f(i,2)=(x(i,1)-2)^2+b;
% end
f(:,1)=x(:,1).^2+b;
f(:,2)=(x(:,1)-2).^2+b;
return